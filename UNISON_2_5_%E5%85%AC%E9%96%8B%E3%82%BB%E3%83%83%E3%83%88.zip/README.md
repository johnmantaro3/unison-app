# UNISON 2.5 — iPhone公開ガイド

## できること
- 5つの音楽サービスの公式検索ページを開く（ログイン不要）
- DJ Discoveryの結果から5サービスを検索する
- Spotify OAuth PKCE と Apple Music MusicKit の認証・検索UI（開発者側設定が必要）

## HTTPS公開（GitHub Pagesの例）
1. GitHubにログインして新規の公開リポジトリ `unison-app` を作成。
2. ZIP内の `index.html` をリポジトリのルートにアップロード。
3. Settings > Pages > Build and deployment > Deploy from a branch を選び、main / (root) を指定して保存。
4. Pagesの公開URLが表示されるまで待つ。例: https://YOURNAME.github.io/unison-app/ （これは例で、実際のURLではありません）。
5. iPhoneのSafariで公開URLを開き、共有 > ホーム画面に追加。

## Spotify認証（オプション）
1. Spotify Developer Dashboardでアプリを登録。利用可否・アカウント要件はSpotifyの最新規約に従う。
2. アプリのRedirect URIに、実際に公開されたURLを完全一致で登録。
3. UNISON > Music ConnectでClient IDと同じRedirect URIを入力。Client Secretは絶対に入力しない。
4. Spotifyにログインを押して認証。アプリ側の権限・ユーザー登録条件により利用できないことがあります。

## Apple Music（オプション）
- Apple Developer登録とMusicKitの正規Developer Tokenが必要です。
- 秘密鍵を公開HTMLに埋め込まないでください。実運用は安全なバックエンドで短期トークンを配布してください。
- Apple Musicの認証・API利用はユーザーのサブスクリプションや利用条件によって制約があります。

## 注意
- これは静的HTMLの試作品で、ホスティングやSpotify/Apple開発者登録を自動実行しません。
- SoundCloud、Bandcamp、Mixcloudは検索リンク連携であり、正式APIログイン連携ではありません。
- 公開URLを知らない人にも見られる公開リポジトリには、秘密鍵・トークン・個人情報を置かないでください。
- 音源候補の存在はMusicBrainzで確認できても、各サービスでの配信やDJ制作であることは保証しません。
